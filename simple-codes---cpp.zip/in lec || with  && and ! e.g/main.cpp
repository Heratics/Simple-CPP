/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    double x = 1.5;
    int y = 20;
    bool z = true ;
    
    if (!(x+1 > 2) && !z || y - 5 == 15 && !false)
            cout << 10;
            
        /*(x + 1 > 2) becomes (true) but !true = false so 
        therefore its false %% !z which is false aswell so 
        false || true 
        true */ 
            
        
        //else 
            //cout << 20;
            
            
    return 0;
}

