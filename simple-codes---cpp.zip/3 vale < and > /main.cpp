/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int x;
    int y;
    int z;
    
    cout << "first value : ";
    cin  >> x;
    
    cout << "second value : ";
    cin  >> y;
    
    cout << "third value : ";
    cin  >> z;
    
    if (x > y)
        if (x > z)
        cout << x;
        else
        cout << z;
        
    else 
        if (y > z)
        cout << y;
        else
        cout << z;
    
    return 0;
}


