/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

 // cin.get means it pulls any character it sees including a space
 
#include <iostream>

using namespace std;

int main()
{
    
    char x, y, z;
    
    cin >> x;
    
    cin.get(y);
    
    cin >> z;
    
    cout << x << y << z;
    
    return 0;
}