/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    double num1;
    double num2;
    double num3;

    cout << "first value : ";
    cin  >> num1;

    cout << "second value : ";
    cin  >> num2;

    cout << "third value : ";
    cin  >> num3;
    
    double maxNumber = fmax(num1, fmax(num2, num3));

    cout << "The maximum value is: " << maxNumber << endl;


    return 0;
}


