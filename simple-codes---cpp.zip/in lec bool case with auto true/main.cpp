/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <iostream>

using namespace std;

int main() {

    bool x = false;
    int y = 50; // the non-bool value as in not true or false is turned into an automatic true without anything else 
    
    if (y)
        cout << 10;
        cout << 20;
    
    return 0;
}